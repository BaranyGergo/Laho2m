﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Rectangle Uto;
        Rectangle Labda;

        SolidBrush ecsetUto;
        SolidBrush ecsetLabda;

        Point pontKurzor;

        Random rnd = new Random();

        bool Megy = false;
        int sebx = 0, seby = 0;

        private void JatekVege()
        {
            Megy = false;
            timer1.Enabled = false;
        }
        void Ujjatek()
        {
            ecsetUto = new SolidBrush(Color.Red);
            ecsetLabda = new SolidBrush(Color.Blue);
            Labda = new Rectangle(rnd.Next(1, ClientSize.Width - 10), rnd.Next(1, ClientSize.Height / 100 * 60 - 10), 10, 10);
            Uto = new Rectangle(ClientSize.Width / 2 - 40, ClientSize.Height / 100 * 90, 80, 30);
            Megy = true;
            Cursor.Hide();

            while (sebx == 0)
            {
                sebx += rnd.Next(-5, 6);
            }

            while (seby == 0)
            {
                seby += rnd.Next(-5, 6);
            }

            timer1.Interval = 1;
            timer1.Enabled = true;
            this.Invalidate();
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                Ujjatek();
            }
            if (e.KeyCode == Keys.Escape)
            {
                Application.Exit();
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (Megy)
            {
                e.Graphics.FillEllipse(ecsetLabda, Labda);
                e.Graphics.FillRectangle(ecsetUto, Uto);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pontKurzor = this.PointToClient(Cursor.Position);
            Uto.X = pontKurzor.X - 40;
            Labda.X += sebx;
            Labda.Y += seby;

            if (0 > Labda.Left)
            {
                sebx = -sebx;
            }
            if (ClientSize.Width < Labda.Right)
            {
                sebx = -sebx;
            }
            if (0 > Labda.Top)
            {
                seby = -seby;
            }
            if (ClientSize.Height < Labda.Bottom)
            {
                sebx = 0;
                seby = 0;
                JatekVege();
            }


            if (Uto.IntersectsWith(Labda))
            {
                sebx++;
                seby++;
                seby = -seby;
                Labda.Y = Uto.Y - 10;
            }



            this.Invalidate();
        }
    }
}
